#ifndef SonarPioneer_h
#define SonarPioneer_h
#include "Arduino.h"
class SonarPioneer {
public:
	SonarPioneer(int S0, int S1, int S2, int tri, int inh, char echo);
	int Read(char nS);
private:
	int _S0;
	int _S1;
	int _S2;
	int _tri;
	int _inh;
	char _echo;
};
#endif