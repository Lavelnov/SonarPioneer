#ifndef SonarPioneer_h
#define SonarPioneer_h
#include "Arduino.h"

class SonarPioneer {
public:
	SonarPioneer(char S0, char S1, char S2, char tri, char inh, char echo);
	int Read(char nS);
private:
	char _S0;
	char _S1;
	char _S2;
	char _tri;
	char _inh;
	char _echo;
};
#endif