#include "SonarPioneer.h"
#include "Arduino.h"
SonarPioneer::SonarPioneer(int S0, int S1, int S2, int tri, int inh, char echo){
pinMode(S0, OUTPUT);
pinMode(S1, OUTPUT);
pinMode(S2, OUTPUT);
pinMode(tri, OUTPUT);
pinMode(inh, OUTPUT);
pinMode(echo, INPUT);

digitalWrite(S0, LOW);
digitalWrite(S1, LOW);
digitalWrite(S2, LOW);
digitalWrite(tri, LOW);
digitalWrite(inh, LOW);
_S0 = S0;
_S1 = S1;
_S2 = S2;
_tri = tri;
_inh = inh;
_echo = echo;
//delay(3000);
}
int SonarPioneer::Read(char nS){
	int flag = 0;
	int ecpin = 0;
	long duration = 0;
	if ((nS & 0x01) ==1){
		digitalWrite(_S0, HIGH);
	}else
		digitalWrite(_S0, LOW);
	if (((nS>>1) & 0x01) == 1){
		digitalWrite(_S1, HIGH);
	}
	else
		digitalWrite(_S1, LOW);
	if (((nS >> 2) & 0x01) == 1){
		digitalWrite(_S2, HIGH);
	}
	else
		digitalWrite(_S2, LOW);
	/*
	bool S0v = (nS && 0x01);
	bool S1v = (nS >> 1);
	bool S2v = (nS >> 2);
	
	bool S1v = (nS >> 1) && (0x01);
	bool S2v = (nS >> 2) && (0x01);
	digitalWrite(_S0, S0v);
	digitalWrite(_S1, S1v);
	digitalWrite(_S1, S2v);*/

	//trigger 
	digitalWrite(_tri, LOW);
	digitalWrite(_inh, LOW);
	delayMicroseconds(1200);
	digitalWrite(_tri, HIGH);
	delayMicroseconds(800);
	digitalWrite(_inh, HIGH);

	//counter
	flag = 1;
	duration = 8;
	do{
		delayMicroseconds(1);
		duration++;
		ecpin = analogRead(A0);
		if (ecpin>600){
			break;
			flag = 0;
		}
		if (duration>300){
			break;
			flag = 0;
		}
	} while (flag = 1);
	delay(38 - duration/1000);
	//regresa el tiempo
	return(duration*3.4 / 2);
}