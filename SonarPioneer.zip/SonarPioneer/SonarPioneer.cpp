#include "SonarPioneer.h"
#include "Arduino.h"
SonarPioneer::SonarPioneer(char S0, char S1, char S2, char tri, char inh, char echo){
pinMode(S0, OUTPUT);
pinMode(S1, OUTPUT);
pinMode(S2, OUTPUT);
pinMode(tri, OUTPUT);
pinMode(inh, OUTPUT);
pinMode(echo, INPUT);

analogWrite(S0, 0);
analogWrite(S1, 0);
analogWrite(S2, 0);
analogWrite(tri, 0);
analogWrite(inh, 0);
_S0 = S0;
_S1 = S1;
_S2 = S2;
_tri = tri;
_inh = inh;
_echo = echo;
//delay(3000);
}
int SonarPioneer::Read(char nS){
	int flag = 0;
	int ecpin = 0;
	long duration = 0;

	//selector de sonar 
	if ((nS & 0x01) ==1){
		analogWrite(_S0, 255);
	}else
		analogWrite(_S0, 0);
	if (((nS>>1) & 0x01) == 1){
		analogWrite(_S1, 255);
	}
	else
		analogWrite(_S1, 0);
	if (((nS >> 2) & 0x01) == 1){
		analogWrite(_S2, 255);
	}
	else
		analogWrite(_S2, 0);



	//trigger 
	analogWrite(_tri, 0);
	analogWrite(_inh, 0);
	delayMicroseconds(1200);
	analogWrite(_tri, 255);
	delayMicroseconds(800);
	analogWrite(_inh,255);

	//counter
	flag = 1;
	duration = 8;
	do{
		delayMicroseconds(1);
		duration++;
		ecpin = analogRead(_echo);
		if (ecpin>600){
			break;
			flag = 0;
		}
		if (duration>300){
			break;
			flag = 0;
		}
	} while (flag = 1);
	delay(38 - duration/1000);
	//regresa el tiempo
	return(duration*3.4 / 2);
}